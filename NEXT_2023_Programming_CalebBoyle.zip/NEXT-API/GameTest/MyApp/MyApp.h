//---------------------------------------------------------------------------------
// MyApp.h
//---------------------------------------------------------------------------------
#ifndef _MYAPP_H
#define _MYAPP_H

#include "..\stdafx.h"


namespace MyApp 
{

	void DrawBox(float sx, float sy, float h, float w, float r, float g, float b);

};

#endif